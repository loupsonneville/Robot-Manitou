define(['libs/iscroll-probe', 'brease/core/Utils', 'brease/events/BreaseEvent'], function (IScroll, Utils, BreaseEvent) {

    'use strict';
    /**
    * @class brease.helper.Scroller
    * @extends core.javascript.Object
    * 
    * @singleton
    */
    var Scroller = {

            init: function (popupManager) {
                if (popupManager !== undefined && typeof popupManager.update === 'function') {
                    _popupManager = popupManager;
                }
                IScroll.prototype.breaseUpdateZoomFactor = function () {
                    this.zoomFactor = Utils.getScaleFactor(this.wrapper);
                };
                IScroll.prototype.subsequentlyDisableMouse = function () {
                    this.wrapper.removeEventListener('mousedown', this);
                    this.wrapper.removeEventListener('mousemove', this);
                    this.wrapper.removeEventListener('mousecancel', this);
                    this.wrapper.removeEventListener('mouseup', this);
                };
                IScroll.prototype.subsequentlyEnableMouse = function () {
                    this.wrapper.addEventListener('mousedown', this);
                    this.wrapper.addEventListener('mousemove', this);
                    this.wrapper.addEventListener('mousecancel', this);
                    this.wrapper.addEventListener('mouseup', this);
                };
                IScroll.prototype.subsequentlyDisableTouch = function () {
                    this.wrapper.removeEventListener('touchstart', this);
                    this.wrapper.removeEventListener('touchmove', this);
                    this.wrapper.removeEventListener('touchcancel', this);
                    this.wrapper.removeEventListener('touchend', this);
                };
                IScroll.prototype.subsequentlyEnableTouch = function () {
                    this.wrapper.addEventListener('touchstart', this);
                    this.wrapper.addEventListener('touchmove', this);
                    this.wrapper.addEventListener('touchcancel', this);
                    this.wrapper.addEventListener('touchend', this);
                };
            },

            /**
            * @method addScrollbars
            * Method to add scrollbars to an area.
            * @param {HTMLElement/Selector} selector
            * @param {Object} options
            * @param {Boolean} noObserver (optional)
            * if set true, no MutationObserver is used
            */
            addScrollbars: function (selector, options, noObserver) {
                var wrapper = typeof selector === 'string' ? document.querySelector(selector) : selector,
                    scroller;
                if (wrapper !== null) {
                    scroller = new IScroll(wrapper, _settings(options));
                    scroller.zoomFactor = Utils.getScaleFactor(wrapper);
                    scroller.on('beforeScrollStart', function () {
                        this.stopped = false;
                        _start(this);
                    });
                    scroller.on('scrollStart', function () {
                        this.options.preventDefault = true;
                        this.wrapper.dispatchEvent(new CustomEvent(BreaseEvent.SCROLL_START, { bubbles: true }));
                    });
                    scroller.on('scrollEnd', function () {
                        this.options.preventDefault = false;
                        if (!this.stopped) {
                            _stop();
                            this.stopped = true;
                        }
                    });
                    scroller.on('scrollCancel', function () {
                        this.options.preventDefault = false;
                        if (!this.stopped) {
                            _stop();
                            this.stopped = true;
                        }
                    });
                    scroller.on('destroy', function () {
                        document.body.removeEventListener(BreaseEvent.APP_RESIZE, this.boundUpdateZoomFactor);
                    });
                    scroller.boundUpdateZoomFactor = scroller.breaseUpdateZoomFactor.bind(scroller);
                    document.body.addEventListener(BreaseEvent.APP_RESIZE, scroller.boundUpdateZoomFactor);
                    _popupManager.update();
                    if (noObserver !== true) {
                        addObserver(wrapper, scroller);
                    }
                } else {
                    scroller = {
                        on: function () { warn(selector); },
                        off: function () { },
                        refresh: function () { },
                        scrollToElement: function () { },
                        scrollTo: function () { },
                        scrollBy: function () { },
                        destroy: function () { },
                        enable: function () { },
                        disable: function () { },
                        wrapper: {}
                    };
                }
                return scroller;
            },

            /**
            * @method disableAllStartedScrollers
            * Method to disable all scroller, which are started by the last touchstart/mousedown event.
            */
            disableAllStartedScrollers: function () {
                for (var key in _safe.scroller) {
                    _safe.scroller[key].disable();
                }
            }

        },
        _safe = {
            scroller: {}
        },
        _popupManager = {
            update: function () { }
        },
        _defaults = {};
    Utils.defineProperty(_defaults, 'bounce', false);
    Utils.defineProperty(_defaults, 'fadeScrollbars', false);
    Utils.defineProperty(_defaults, 'momentum', true);
    Utils.defineProperty(_defaults, 'mouseWheel', false);
    Utils.defineProperty(_defaults, 'resizeScrollbars', true);
    Utils.defineProperty(_defaults, 'scrollbars', 'custom');

    //A&P 584175: allow browser zoom in scroll containers
    // browser zoom is the default behaviour of pinch-to-zoom gesture and can be prevented with event.preventDefault
    // setting this to false in combination with touch-action:'pinch-zoom', enables other default browser gestures too, e.g. overscroll history navigation
    Utils.defineProperty(_defaults, 'preventDefault', false);

    // A&P 512800: fix for iScroll/Chrome 55 issue
    Utils.defineProperty(_defaults, 'disableTouch', false);
    Utils.defineProperty(_defaults, 'disableMouse', false);
    Utils.defineProperty(_defaults, 'disablePointer', true);

    // A&P 517465: against fuzzy zoomed content in chrome
    Utils.defineProperty(_defaults, 'HWCompositing', false);

    Utils.defineProperty(Scroller, 'defaults', _defaults);

    function _settings(options) {
        var settings = $.extend({}, Scroller.defaults, options);
        settings.disableTouch = false;
        settings.disableMouse = false;
        settings.disablePointer = true;
        settings.HWCompositing = false;
        return settings;
    }

    function _start(scroller) {

        if (scroller.hasHorizontalScroll || scroller.hasVerticalScroll) {

            // find an id to save the scroller
            var id = $(scroller.wrapper).closest('[id]')[0].id;
            _safe.scroller[id] = scroller;

            // iterate over all other started scrollers and disable this one, 
            // if its wrapper is an ancestor of another started scrollers wrapper
            // (this is working, because the most inner scroller is activated first)
            for (var key in _safe.scroller) {
                if (_safe.scroller[key] !== scroller) {
                    if ($.contains(scroller.wrapper, _safe.scroller[key].wrapper)) {
                        scroller.disable();
                        break;
                    }
                }
            }
        }
    }

    function _stop() {
        if (_safe.stopped !== true) {
            _safe.stopped = true;
            window.setTimeout(function () {
                for (var key in _safe.scroller) {
                    var scroller = _safe.scroller[key];
                    if (!scroller.enabled) {
                        scroller.initiated = 0;
                        scroller.enable();
                    }
                }
                _safe.scroller = {};
                _safe.stopped = false;
            }, 0);
        }
    }

    function addObserver(HTMLnode, scroller) {
        if (typeof MutationObserver === 'function') {
            var observer = new MutationObserver(handleMutations);

            observer.debouncedRefresh = _.debounce(_refresh.bind(null, scroller, observer), 300);
            observer.observe(HTMLnode, { childList: true, subtree: true });
        }
    }

    function _refresh(scroller, observer) {
        if (scroller.wrapper && scroller.wrapper.ownerDocument === document) {
            scroller.refresh();
        }
        observer.disconnect();
        observer.debouncedRefresh = null;
    }

    function handleMutations(mutations, observer) {
        var refresh = false;

        mutations.forEach(function (mutation) {
            if (mutation.addedNodes.length > 0) {
                refresh = true;
            }
        });
        if (refresh) {
            observer.debouncedRefresh();
        }
    }

    function warn(selector) {
        console.iatWarn('trying to add a scroller to a null object:' + selector);
    }

    return Scroller;
});
