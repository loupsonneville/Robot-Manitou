#ifndef _ENVOIETRAMESCAN_DEFAULT_1835911160
#define _ENVOIETRAMESCAN_DEFAULT_1835911160
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
