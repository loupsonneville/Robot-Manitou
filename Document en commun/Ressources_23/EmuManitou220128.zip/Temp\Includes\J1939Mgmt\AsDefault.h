#ifndef _J1939MGMT_DEFAULT_2073894290
#define _J1939MGMT_DEFAULT_2073894290
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
