/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1651158450_3_
#define _BUR_1651158450_3_

#include <bur/plctypes.h>

/* Datatypes and datatypes of function blocks */
typedef struct ColumnByteHMI
{	plcbyte Data[6];
} ColumnByteHMI;

typedef struct ColumnByteMotor
{	plcbyte Data[14];
} ColumnByteMotor;

typedef struct ColumnByteSPU
{	plcbyte Data[3];
} ColumnByteSPU;






__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/ActualiisationTrames/Types.typ\\\" scope \\\"local\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1651158450_3_ */

