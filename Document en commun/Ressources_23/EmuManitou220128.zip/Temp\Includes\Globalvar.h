/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1654690762_1_
#define _BUR_1654690762_1_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
 _WEAK const plcstring ID_SPU[3][81] = {"18FF1021","18FF2021","18FF3021"};
 _WEAK const plcstring IDTramesHMI[6][81] = {"18FF2017","18FEDA17","18FEEB17","18FEFC17","18FF1017","18E00017"};
 _WEAK const plcstring IDTramesMoteur[14][81] = {"18EBFF00","18ECFF00","0CF00400","18FD1C00","18FD7B00","18FD7C00","18FECA00","18FEE400","18FEE500","18FEEE00","18FEEF00","18FEF200","18FEF600","18FEFF00"};
 _WEAK const plcstring NameTramesSPU[3][81] = {"SPU_IHM_TRAME1","SPU_IHM_TRAME2","SPU_IHM_TRAME3"};
 _WEAK const plcstring NameTramesHMI[6][81] = {"HMI_INFO_TX_ICONS","HMI_SW_INFORMATIONS","HMI_SERIAL_NUMBER","HMI_FUEL_LEVEL1","HMI_INFO_TX_INPUT","CM1"};
 _WEAK const plcstring NameTramesMoteur[14][81] = {"TP_DT","TP_CM","EEC1","DPF1S","AT1S","DPFC1","DM1","SHUTDN","HOURS","ET1","EFL_P1","LFE","IC1","WFI"};
#else
 _GLOBAL_CONST plcstring ID_SPU[3][81];
 _GLOBAL_CONST plcstring IDTramesHMI[6][81];
 _GLOBAL_CONST plcstring IDTramesMoteur[14][81];
 _GLOBAL_CONST plcstring NameTramesSPU[3][81];
 _GLOBAL_CONST plcstring NameTramesHMI[6][81];
 _GLOBAL_CONST plcstring NameTramesMoteur[14][81];
#endif


/* Variables */
_GLOBAL plcstring New_Variable[81];
_GLOBAL plcbit Start;
_GLOBAL unsigned char gCompteurTramesSend;
_GLOBAL struct ArCanFrameType gTableauTramesSend[100];
_GLOBAL struct Trame SPU_0x21[3];
_GLOBAL struct Trame Motor_0x00[14];
_GLOBAL struct Trame HMI_0x17[6];





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/Global.var\\\" scope \\\"global\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1654690762_1_ */

