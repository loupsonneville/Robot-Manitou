#ifndef _RCEPTIONTRAMESCAN_DEFAULT_108581089
#define _RCEPTIONTRAMESCAN_DEFAULT_108581089
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
