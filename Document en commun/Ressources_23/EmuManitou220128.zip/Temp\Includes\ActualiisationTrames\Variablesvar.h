/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1652109347_1_
#define _BUR_1652109347_1_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
#else
#endif


/* Variables */
_BUR_LOCAL unsigned char n;
_BUR_LOCAL unsigned char m;
_BUR_LOCAL unsigned char l;
_BUR_LOCAL unsigned char k;
_BUR_LOCAL unsigned char j;
_BUR_LOCAL unsigned char i;
_BUR_LOCAL struct ColumnByteSPU TramesSPU[8];
_BUR_LOCAL struct ColumnByteHMI TramesHMI[8];
_BUR_LOCAL struct ColumnByteMotor TramesMoteur[8];





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/ActualiisationTrames/Variables.var\\\" scope \\\"local\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1652109347_1_ */

