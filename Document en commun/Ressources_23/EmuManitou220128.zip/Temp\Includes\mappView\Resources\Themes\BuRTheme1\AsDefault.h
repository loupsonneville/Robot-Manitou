#ifndef _MAPPVIEW_RESOURCES_THEMES_BURTHEME1_DEFAULT_1491230395
#define _MAPPVIEW_RESOURCES_THEMES_BURTHEME1_DEFAULT_1491230395
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#endif
