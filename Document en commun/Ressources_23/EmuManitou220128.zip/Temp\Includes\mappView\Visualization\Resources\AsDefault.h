#ifndef _MAPPVIEW_VISUALIZATION_RESOURCES_DEFAULT_1169432132
#define _MAPPVIEW_VISUALIZATION_RESOURCES_DEFAULT_1169432132
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#endif
