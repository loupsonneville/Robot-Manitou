#ifndef _MAPPVIEW_VISUALIZATION_DIALOGS_DEFAULT_406687584
#define _MAPPVIEW_VISUALIZATION_DIALOGS_DEFAULT_406687584
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#endif
