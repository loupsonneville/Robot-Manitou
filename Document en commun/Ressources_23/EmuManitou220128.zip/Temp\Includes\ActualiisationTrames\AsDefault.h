#ifndef _ACTUALIISATIONTRAMES_DEFAULT_1014020649
#define _ACTUALIISATIONTRAMES_DEFAULT_1014020649
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
