#ifndef _RECEPTIONTRAMESCAN_DEFAULT_1510675275
#define _RECEPTIONTRAMESCAN_DEFAULT_1510675275
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
