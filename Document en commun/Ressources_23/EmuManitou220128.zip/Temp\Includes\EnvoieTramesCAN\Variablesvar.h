/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1651158450_2_
#define _BUR_1651158450_2_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
#else
#endif


/* Variables */
_BUR_LOCAL unsigned char MachineStateSendCan;
_BUR_LOCAL struct ArCanSend ArCanSender;
_BUR_LOCAL unsigned char j;
_BUR_LOCAL unsigned char i;
_BUR_LOCAL struct ArCanSend ArCanSenderMotor[14];
_BUR_LOCAL struct ArCanSend ArCanSenderSPU[3];





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/EnvoieTramesCAN/Variables.var\\\" scope \\\"local\\\"\\n\"");
__asm__(".ascii \"iecfile \\\"Logical/Libraries/ArCan/ArCan.fun\\\" scope \\\"global\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1651158450_2_ */

