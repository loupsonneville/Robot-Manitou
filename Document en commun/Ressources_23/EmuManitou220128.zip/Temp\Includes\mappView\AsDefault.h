#ifndef _MAPPVIEW_DEFAULT_85624382
#define _MAPPVIEW_DEFAULT_85624382
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#endif
