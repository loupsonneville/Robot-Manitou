#ifndef _PROGRAM2_DEFAULT_522632958
#define _PROGRAM2_DEFAULT_522632958
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
