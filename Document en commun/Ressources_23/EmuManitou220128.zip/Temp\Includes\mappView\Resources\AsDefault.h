#ifndef _MAPPVIEW_RESOURCES_DEFAULT_634364367
#define _MAPPVIEW_RESOURCES_DEFAULT_634364367
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#endif
